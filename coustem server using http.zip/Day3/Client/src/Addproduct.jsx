import axios from "axios";
import React, { useState } from "react";

const initialState = {
  title: "",
  image: "",
  price: "",
  category: "",
  discription: "",
};

const Addproduct = () => {
  const [formdata, setformdata] = useState(initialState);

  const { title, image, price, discription, category } = formdata;

  const handeleChange = (e) => {
    setformdata({ ...formdata, [e.target.name]: e.target.value });
  };

  const handelesubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:3500/addproduct", formdata)
      .then((res) => {
        console.log(res.data);
        
        
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div>
      <form onSubmit={handelesubmit}>
        <input
          type="text"
          value={title}
          name="title"
          onChange={handeleChange}
          placeholder="Title"
        />
        <br /> <br />
        <input
          type="text"
          value={image}
          name="image"
          onChange={handeleChange}
          placeholder="Image URL"
        />
        <br /> <br />
        <input
          type="number"
          value={price}
          name="price"
          onChange={handeleChange}
          placeholder="Price"
        />
        <br /> <br />
        <select value={category} name="category" onChange={handeleChange}>
          <option value="">Select Category</option>
          <option value="men's clothing">Men's Clothing</option>
          <option value="women's clothing">Women's Clothing</option>
          <option value="jewelery">Jewelry</option>
          <option value="electronics">Electronics</option>
        </select>
        <br /> <br />
        <input
          type="text"
          value={discription}
          name="discription"
          onChange={handeleChange}
          placeholder="Description"
        />
        <br /> <br />
        <input type="submit" value="Add Product" />
        <br />
        <br />
      </form>
    </div>
  );
};

export default Addproduct;
