import axios from "axios";
import React, { useEffect, useState } from "react";

const Product = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/Product")
      .then((res) => {
        console.log("API Response:", res.data); // ✅ Check API response
        setData(res.data.Product || []); // Ensure it's an array
      })
      .catch((err) => {
        console.error("Error fetching data:", err);
      });
  }, []);
  

  // Delete product and update UI
  const handleDelete = (id) => {
    if (!id) {
      console.error("Invalid product ID");
      return;
    }

    axios
      .delete(`http://localhost:8080/deleteproduct/${id}`)
      .then((res) => {
        console.log("Product deleted:", res.data);
        // Update UI after deletion
        setData((prevData) => prevData.filter((product) => product.id !== id));
      })
      .catch((err) => {
        console.error("Error deleting product:", err);
      });
  };

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)" }}>
        {data.length > 0 ? (
          data.map((el) => (
            <div key={el.id}>
              {" "}
              {/* Ensure key exists */}
              <img src={el.image} alt={el.title} height={200} width={200} />
              <h3>{el.title}</h3>
              <h2>${el.price}</h2>
              <p>{el.description}</p>
              <h2>{el.category}</h2>
              <button onClick={() => handleDelete(el.id)}>Delete</button>
            </div>
          ))
        ) : (
          <h2>No Products Available</h2>
        )}
      </div>
    </div>
  );
};

export default Product;
