import React from 'react'
import Product from './product'
import Addproduct from './Addproduct'



const App = () => {
  return (
    <div>
    <Addproduct/>
      <Product/>
    </div>
  )
}

export default App