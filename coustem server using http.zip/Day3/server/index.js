let http = require("http");
let fs = require('fs');

let server = http.createServer((request, response) => {
  // Set CORS headers manually
  response.setHeader("Access-Control-Allow-Origin", "*");
  response.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, PATCH, OPTIONS");
  response.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (request.method === "OPTIONS") {
    response.writeHead(204);
    return response.end();
  }

  response.writeHead(200, { "Content-Type": "application/json" });

  if (request.method == 'GET' && request.url == '/Product') {
    fs.readFile('./db.json', 'utf-8', (err, data) => {
      if (err) {
        response.end(err);
      } else {
        let parsedData = JSON.parse(data);
        response.end(JSON.stringify({ Product: parsedData})); // Ensure correct key
      }
    });
  

  } else if (request.method == 'GET' && request.url.startsWith('/Discription/')) {
    let productId = request.url.split('/')[2];
    fs.readFile('./db.json', 'utf-8', (err, data) => {
      if (err) {
        response.end(JSON.stringify({ error: err.message }));
      } else {
        const { Product } = JSON.parse(data);
        const filterdata = Product.find((el) => el.id == productId);
        response.end(JSON.stringify(filterdata || { error: "Product not found" }));
      }
    });

  } else if (request.method == "POST" && request.url == '/Addproduct') {
    let str = '';
    request.on('data', (Piece) => {
      str += Piece;
    });

    request.on('end', () => {
      let ProductData = JSON.parse(str);
      fs.readFile('./db.json', 'utf-8', (err, dbData) => {
        if (err) {
          response.end(JSON.stringify({ error: err.message }));
        } else {
          let Maindata = JSON.parse(dbData);
          let newProduct = { ...ProductData, id: Date.now().toString() };
          Maindata.Product.push(newProduct);

          fs.writeFile('./db.json', JSON.stringify(Maindata), (err) => {
            if (err) {
              response.end(JSON.stringify({ error: err.message }));
            } else {
              response.end(JSON.stringify({ message: "Product Added", product: newProduct }));
            }
          });
        }
      });
    });

  } else if (request.method == 'DELETE' && request.url.startsWith('/deleteproduct/')) {
    let ProductId = request.url.split('/')[2];
    fs.readFile('./db.json', 'utf-8', (err, data) => {
      if (err) {
        response.end(JSON.stringify({ error: err.message }));
      } else {
        let FinalData = JSON.parse(data);
        let filteredData = FinalData.Product.filter((el) => el.id !== ProductId);

        if (filteredData.length === FinalData.Product.length) {
          return response.end(JSON.stringify({ error: "Product not found" }));
        }

        fs.writeFile('./db.json', JSON.stringify({ Product: filteredData }), (err) => {
          if (err) {
            response.end(JSON.stringify({ error: err.message }));
          } else {
            response.end(JSON.stringify({ message: "Product Deleted" }));
          }
        });
      }
    });

  } else if (request.method == 'PATCH' && request.url.startsWith('/UpdateProduct/')) {
    let UpdateId = request.url.split("/")[2];
    let str = '';
    request.on('data', (pieces) => {
      str += pieces;
    });

    request.on('end', () => {
      let updateProductData = JSON.parse(str);
      fs.readFile('./db.json', 'utf-8', (error, data) => {
        if (error) {
          response.end(JSON.stringify({ error: error.message }));
        } else {
          let MainData = JSON.parse(data);
          let updated = false;

          let FinalData = MainData.Product.map((item) => {
            if (item.id == UpdateId) {
              updated = true;
              return { ...item, ...updateProductData };
            }
            return item;
          });

          if (!updated) {
            return response.end(JSON.stringify({ error: "Product not found" }));
          }

          MainData.Product = FinalData;

          fs.writeFile('./db.json', JSON.stringify(MainData), (err) => {
            if (err) {
              response.end(JSON.stringify({ error: err.message }));
            } else {
              response.end(JSON.stringify({ message: "Product Updated" }));
            }
          });
        }
      });
    });

  } else {
    response.end(JSON.stringify({ error: "Endpoint not found" }));
  }
});

server.listen(8080, () => {
  console.log("Server running on http://localhost:8080");
});
